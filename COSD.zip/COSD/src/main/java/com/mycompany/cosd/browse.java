package com.mycompany.cosd;

/**
 *
 * @author shantanuunde
 */
public class browse {
    private String filter;

    // Constructor
    public browse() {
    }

    // Getter and setter for filter
    public String getFilter() {
        return filter;
    }

    public void setFilter(String filter) {
        this.filter = filter;
    }
}
