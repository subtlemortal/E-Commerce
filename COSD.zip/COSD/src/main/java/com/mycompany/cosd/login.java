package com.mycompany.cosd;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author shantanuunde
 */
public class login {
    private String username;
    private String password;

    // Constructor
    public login() {
    }

    // Getters and setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = "shantanu";
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = "1234";
    }
}
