
package com.mycompany.cosd;

/**
 *
 * @author shantanuunde
 */
public class BuyP {
    private int quantity;
    private int productId;

    // Constructor
    public BuyP() {
    }

    // Getters and setters
    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }
}
